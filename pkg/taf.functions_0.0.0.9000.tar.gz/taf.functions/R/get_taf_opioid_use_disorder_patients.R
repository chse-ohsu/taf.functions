#' Name: get_taf_opioid_use_disorder_patients
#' DESCRIPTION: returns a dataframe with the msis_id, bene_id, and state_cd of 
#' every beneficiary in the input data with an opioid related disorder, defined  
#' using the National Quality Forum (NQF 12) approach:
#' 
#' "enrollees with OUD diagnoses (using International Classification of Diseases, 
#' Ninth Revision [ICD-9] codes 304.0x, 305.5x and ICD-10 codes F11.xxx) recorded 
#' during an inpatient stay or a visit to an outpatient facility or office." The
#' specific implications of this when working with TAF are that inpatient and 
#' outpatient diagnostic codes will be considered (meaning all columns labeled
#' dgns code in the taf_inpatient_header adn taf_other_services_header, as 
#' oupatient codes are stored in the other services header file). However, long
#' term care diagnostic codes will not be considered.
#' 
#' @param taf_inpatient_df - dataframe - data from the 'taf_inpatient_header' 
#' file (contains inpatient ICD codes)
#'  
#' @param taf_other_services_df - dataframe - data from the 
#' 'taf_other_services_header' file (contains outpatient ICD codes)
#'  
#' @param year_col - string - OPTIONAL (defaults to NULL) - name of the column 
#' containing the year the data is from, e.g. if your year data is in a column 
#' named 'year', put 'year'. Since TAF data arrives in separate files by year,
#' there is no column to identify year in each file in the raw taf data, you 
#' must add it yourself when using multiple years of TAF data. This parameter 
#' should ALWAYS be used if there are multiple years of data in your dataframe.
#'  
#' @param allow_invalid_codes - boolean - OPTIONAL (defaults to TRUE) - some ICD 
#' codes are entered incorrectly, but it can still be inferred that they refer 
#' to some sort of opioid use disorder. All ICD10 codes for OUD start with F11 - 
#' thus, an invalid code starting with F11 will likely have some OUD. This input 
#' defaults to TRUE - if it is set to FALSE, patients with invalid codes will 
#' be excluded from the results.
#'  
#' @param opioid_related_disorder_icd_codes - list- OPTIONAL - defaults to the 
#' list of ICD  codes for OUD, based on the NQF 12 approach described above and 
#' returned by the get_icd_codes_for_opioid_use_disorder in this package. If you 
#' want to use a different definition, you may add override this input with your
#' own list or vector of ICD codes. IMPORTANT NOTE: if you wish to do this, 
#' you must also use 'allow_invalid_codes=FALSE' (there is no way of know if - say - an 
#' invalid F11.x code belongs in list that only includes some F11 codes)
#' 
#' @return dataframe with the bene_id, msis_id, state_cd, and if year_col is
#' provided, year, of each TAF beneficiary with an opioid related disorder. Each
#' patient is included only once per year (once only if year is not provided).
#' As such, the number of rows of the dataframe (or number of rows for each year)
#' is the number of opioid related disorder patient.
#' @export
#*******************************************************************************
get_taf_opioid_use_disorder_patients <- function(
    taf_inpatient_df,
    taf_other_services_df,
    year_col=NULL,
    allow_invalid_codes=TRUE,
    opioid_related_disorder_icd_codes=list(
      opioid_type_dependence='304.0',
      opioid_type_dependence_unspecified='304.00',
      opioid_type_dependence_continuous='304.01',
      opioid_type_dependence_episodic='304.02',
      opioid_type_dependence_in_remission='304.03',
      nondependent_opioid_abuse='305.5', 
      opioid_abuse_unspecified='305.50',
      opioid_abuse_continuous='305.51',
      opioid_abuse_episodic='305.52', 
      opioid_abuse_in_remission='305.53',
      opioid_related_disorders='F11',
      opioid_abuse='F11.1',
      uncomplicated='F11.10',
      in_remission='F11.11',
      with_intoxication='F11.12',
      with_intoxication_uncomplicated='F11.120',
      with_intoxication_delirium='F11.121',
      with_intoxication_with_perpetual_disturbance='F11.122',
      with_intoxication_unspecified='F11.129',
      with_withdrawal='F11.13',
      with_opioid_induced_mood_disorder='F11.14',
      with_opioid_induced_psychotic_disorder='F11.15',
      with_opioid_induced_psychotic_disorder_with_delusions='F11.150',
      with_opioid_induced_psychotic_disorder_with_hallucinations='F11.151',
      with_opioid_induced_psychotic_disorder_unspecified='F11.159',
      with_other_opioid_induced_disorder='F11.18',
      with_other_opioid_induced_disorder_with_opioid_induced_sexual_dysfunction='F11.181',
      with_other_opioid_induced_disorder_with_opioid_induced_sleep_disorder='F11.182',
      with_other_opioid_induced_disorder_with_other_opioid_induced_disorder='F11.188',
      with_unspecified_opioid_induced_disorder='F11.19',
      opioid_dependence='F11.2',
      uncomplicated='F11.20',
      in_remission='F11.21',
      with_intoxication='F11.22',
      uncomplicated='F11.220',
      delirium='F11.221',
      with_perceptual_disturbance='F11.222',
      unspecified='F11.229',
      with_withdrawal='F11.23',
      with_opioid_induced_mood_disorder='F11.24',
      with_opioid_induced_psychotic_disorder='F11.25',
      with_delusions='F11.250',
      with_hallucinations='F11.251',
      unspecified='F11.259',
      with_other_opioid_induced_disorder='F11.28',
      with_opioid_induced_sexual_dysfunction='F11.281',
      with_opioid_induced_sleep_disorder='F11.282',
      with_other_opioid_induced_disorder='F11.288',
      with_unspecified_opioid_induced_disorder='F11.29',
      opioid_use_unspecified='F11.9',
      uncomplicated='F11.90',
      in_remission='F11.91',
      with_intoxication='F11.92',
      uncomplicated='F11.920',
      delirium='F11.921',
      with_perceptual_disturbance='F11.922',
      unspecified='F11.929',
      with_withdrawal='F11.93',
      with_opioid_induced_mood_disorder='F11.94',
      with_opioid_induced_psychotic_disorder='F11.95',
      with_delusions='F11.950',
      with_hallucinations='F11.951',
      unspecified='F11.959',
      with_other_specified_opioid_induced_disorder='F11.98',
      with_opioid_induced_sexual_dysfunction='F11.981',
      with_opioid_induced_sleep_disorder='F11.982',
      with_other_opioid_induced_disorder='F11.988',
      with_unspecified_opioid_induced_disorder='F11.99'
    )
){
  
  #taf_inpatient_header has inpatient ICD codes, taf_other_services_header has
  #outpatient ICD codes, these are all the ICD codes used in the NQF 12 approach
  #taf_long_term_header also has ICD codes, but these are excluded, consistent
  #with the NQF approach
  taf_inpatient_df <- as.data.frame(taf_inpatient_df)
  taf_other_services_df <- as.data.frame(taf_other_services_df)
  taf_dataframes_list <- list(taf_inpatient_df, taf_other_services_df)
  
  #create empty data frame with output columns - this allows output data
  #to be added via rbind
  out_df <- taf_inpatient_df[0, c('bene_id', 'msis_id', 'state_cd', year_col)]
  
  #loop through dataframes with relevant ICD codes
  for (taf_df in taf_dataframes_list){
    icd_code_cols <- colnames(taf_df)[grepl('dgns_cd', colnames(taf_df))]
    
    #loop through all columns with ICD codes and check for ICD codes of interest
    for(col in icd_code_cols){
      
      #sometimes, there are codes like 11.183, which are invalid ICD codes
      #however, since all 11.18x codes refer to opioid-related disorders, you
      #can reasonably conclude the patient had an opioid use disorder
      if (allow_invalid_codes){
        taf_df <- taf_df[
            grepl('F11', taf_df[, col])   | 
            grepl('304.0', taf_df[, col]) | 
            grepl('305.5', taf_df[, col]) | 
            grepl('3040', taf_df[, col])  | 
            grepl('3055', taf_df[, col]),]
      } else {
        #adhere strictly to codes within the list of valid ICD codes related to
        #opioid use disorders
        opioid_related_disorder_icd_codes.2 <- gsub("\\.", "", opioid_related_disorder_icd_codes)
        taf_df <- taf_df[taf_df[, col] %in% opioid_related_disorder_icd_codes | taf_df[, col] %in% opioid_related_disorder_icd_codes.2,]
      }
      
      #add the information of beneficiaries with opioid related disorders to the 
      #output dataframe
      out_df <- rbind(out_df, taf_df[, c('bene_id', 'msis_id', 'state_cd', year_col)])
    }
  }
  
  # remove duplicate patients (there are many - if the same person showed up for
  # services more than once, a duplicate row would be created)
  # if the same person showed up in multiple states or years, multiple rows
  # would be created
  out_df <- unique(out_df)
  
  return(out_df)
}